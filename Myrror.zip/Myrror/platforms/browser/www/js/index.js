document.addEventListener("deviceready", onDeviceReady, false);
function onDeviceReady() {

}